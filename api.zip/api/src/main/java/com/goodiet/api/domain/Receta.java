package com.goodiet.api.domain;


import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Receta {
	
	@Id
	@GeneratedValue
	Long id;

	String name;
	String description;
	String ingredients;
	String instructions;
	int time;
	int rate;
	
	@OneToMany(mappedBy = "receta")
	@JsonManagedReference
	List<Categoria> categorias;
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIngredients() {
		return ingredients;
	}

	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}

	public String getInstructions() {
		return instructions;
	}

	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}
	
	public List<Categoria> getCategorias() {
		return categorias;
	}

	public void setCategorias(List<Categoria> categorias) {
		this.categorias = categorias;
	}

	
	

	@Override
	public String toString() {
		return "Receta [nombre=" + name + ", Descripción=" + description + ", Ingredientes=" + ingredients + ", Instrucciones="
				+ instructions + ", Tiempo=" + time + ", Puntuación=" + rate + "]";
	}
	

}
