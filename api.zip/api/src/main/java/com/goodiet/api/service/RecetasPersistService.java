package com.goodiet.api.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.goodiet.api.domain.Receta;
import com.goodiet.api.repository.RecetasRepository;


@Service
public class RecetasPersistService {

	RecetasRepository recetasRepository;
	
	public RecetasPersistService(RecetasRepository recetasRepository) {
		this.recetasRepository = recetasRepository;
	}
	
	public Receta getReceta (Long id) {
		return recetasRepository.getOne(id);
	}
	
	public Long add(Receta receta) {
		Receta recetaGuardada = recetasRepository.save(receta);
		return recetaGuardada.getId();
	}
	
	public List<Receta> getRecetas() {
		return recetasRepository.findAll();
		
	}
	
	public void guarda(Long id, Receta receta ) {
		Receta recetaGuardada = recetasRepository.getOne(id);
		recetaGuardada.setName(receta.getName());
		recetaGuardada.setDescription(receta.getDescription());
		recetaGuardada.setIngredients(receta.getIngredients());
		recetaGuardada.setInstructions(receta.getInstructions());
		recetaGuardada.setTime(receta.getTime());
		recetaGuardada.setRate(receta.getRate());
		recetasRepository.save(recetaGuardada);
	}
	
	public void borra (Long id) {
		recetasRepository.delete(recetasRepository.getOne(id));
	}
	
	public Optional<Receta> findById(Long id) {
		return recetasRepository.findById(id);
	}
}
