package com.goodiet.api.web;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.goodiet.api.domain.Categoria;
import com.goodiet.api.repository.CategoriasRepository;

@RestController
public class CategoriasController {

	
	CategoriasRepository categoriasRepository;
	
	public CategoriasController(CategoriasRepository categoriasRepository) {
		this.categoriasRepository = categoriasRepository;
	}
	
	@GetMapping(path="/categorias")
	List<Categoria> getCategorias() {
		return categoriasRepository.findAll();
	}
	
	@PostMapping(path="/categorias")
	Categoria altaCategoria(@RequestBody Categoria Categoria) {
		return categoriasRepository.save(Categoria);
	}
}
