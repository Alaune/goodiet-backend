package com.goodiet.api.web;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.goodiet.api.domain.Receta;
import com.goodiet.api.service.RecetasPersistService;
import com.goodiet.api.web.error.CustomError;


@RestController
public class RecetasController {
	
	@Autowired 
	RecetasPersistService recetasPersistService;			

	
	@GetMapping(path = "/recetas")
	List<Receta> getRecetas() {			
		return recetasPersistService.getRecetas();		
	}
	
	
	@GetMapping(path = "/recetas/{id}")
	Receta getRecetas(@PathVariable Long id){	
		if (recetasPersistService.findById(id).isPresent()) {
			return recetasPersistService.findById(id).get();
		} else {
			throw new CustomError ("No encuentro esa receta.");
		}
	}
	
	@PostMapping(path = "/recetas")
	Long altaReceta(@RequestBody Receta receta ) {				
		return recetasPersistService.add(receta);		
	}
	
	@PutMapping(path = "/recetas/{id}")
	Receta modificaReceta(@RequestBody Receta receta,@PathVariable Long id){
		recetasPersistService.guarda(id, receta);			
		return receta;		
	}
	
	@DeleteMapping(path="/recetas/{id}")
	String borraReceta(@PathVariable Long id) {	
		recetasPersistService.borra(id);	
		return("OK");
	}
	
	@GetMapping(path = "/recetasHeader")
	ResponseEntity<List<Receta>> getRecetasHeader(){		
		HttpHeaders headers = new HttpHeaders();
		headers.add("MiHeaderRespuesta", "HeaderRespuesta");
		
		return ResponseEntity.ok().headers(headers).body(recetasPersistService.getRecetas());
	}
	
	
	

}