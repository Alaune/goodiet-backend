package com.goodiet.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.goodiet.api.domain.Receta;


@Repository
public interface RecetasRepository extends JpaRepository<Receta, Long> {

}
