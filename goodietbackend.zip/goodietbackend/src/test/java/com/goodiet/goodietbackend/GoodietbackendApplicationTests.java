package com.goodiet.goodietbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoodietbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
