package com.goodiet.goodietbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoodietbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoodietbackendApplication.class, args);
	}

}
